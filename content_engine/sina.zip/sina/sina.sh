 #!/bin/bash 
cd `dirname $0`
python sinapost.py

